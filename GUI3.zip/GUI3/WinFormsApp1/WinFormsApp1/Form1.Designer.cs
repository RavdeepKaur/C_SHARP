﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            groupBox1 = new GroupBox();
            errorlabel = new Label();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            label3 = new Label();
            lastname = new TextBox();
            firstname = new TextBox();
            label2 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            groupBox2 = new GroupBox();
            label5 = new Label();
            comboBox2 = new ComboBox();
            label4 = new Label();
            comboBox1 = new ComboBox();
            button1 = new Button();
            groupBox3 = new GroupBox();
            repass = new TextBox();
            pass = new TextBox();
            textBox3 = new TextBox();
            label8 = new Label();
            Password = new Label();
            Username = new Label();
            passworderror = new Label();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.Info;
            groupBox1.Controls.Add(errorlabel);
            groupBox1.Controls.Add(radioButton2);
            groupBox1.Controls.Add(radioButton1);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(lastname);
            groupBox1.Controls.Add(firstname);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(61, 38);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(510, 124);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Personal Detials";
            // 
            // errorlabel
            // 
            errorlabel.AutoSize = true;
            errorlabel.ForeColor = Color.Red;
            errorlabel.Location = new Point(42, 102);
            errorlabel.Name = "errorlabel";
            errorlabel.Size = new Size(0, 15);
            errorlabel.TabIndex = 7;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(419, 35);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(63, 19);
            radioButton2.TabIndex = 6;
            radioButton2.TabStop = true;
            radioButton2.Text = "Female";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(353, 33);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(51, 19);
            radioButton1.TabIndex = 5;
            radioButton1.TabStop = true;
            radioButton1.Text = "Male";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(302, 33);
            label3.Name = "label3";
            label3.Size = new Size(45, 15);
            label3.TabIndex = 4;
            label3.Text = "Gender";
            // 
            // lastname
            // 
            lastname.Location = new Point(125, 69);
            lastname.Name = "lastname";
            lastname.Size = new Size(100, 23);
            lastname.TabIndex = 3;
            // 
            // firstname
            // 
            firstname.Location = new Point(125, 33);
            firstname.Name = "firstname";
            firstname.Size = new Size(100, 23);
            firstname.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(35, 72);
            label2.Name = "label2";
            label2.Size = new Size(63, 15);
            label2.TabIndex = 1;
            label2.Text = "Last Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(35, 36);
            label1.Name = "label1";
            label1.Size = new Size(64, 15);
            label1.TabIndex = 0;
            label1.Text = "First Name";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(617, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(171, 150);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(comboBox2);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(comboBox1);
            groupBox2.Location = new Point(61, 186);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(510, 133);
            groupBox2.TabIndex = 2;
            groupBox2.TabStop = false;
            groupBox2.Text = "Address Details";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(257, 38);
            label5.Name = "label5";
            label5.Size = new Size(53, 15);
            label5.TabIndex = 3;
            label5.Text = "Province";
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Ontario", "British Columbia" });
            comboBox2.Location = new Point(332, 32);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(121, 23);
            comboBox2.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(27, 40);
            label4.Name = "label4";
            label4.Size = new Size(28, 15);
            label4.TabIndex = 1;
            label4.Text = "City";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Mississauga", "Burlington", "Oakville", "Brampton", "Scarorough", "North York", "Vancouver", "Surrey", "Richmond", "Abbotsford", "Delta", "" });
            comboBox1.Location = new Point(96, 37);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 0;
            comboBox1.SelectedIndexChanged += citySelected;
            comboBox1.TextChanged += comboBox1_TextChanged;
            // 
            // button1
            // 
            button1.Location = new Point(211, 515);
            button1.Name = "button1";
            button1.Size = new Size(106, 31);
            button1.TabIndex = 3;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(passworderror);
            groupBox3.Controls.Add(repass);
            groupBox3.Controls.Add(pass);
            groupBox3.Controls.Add(textBox3);
            groupBox3.Controls.Add(label8);
            groupBox3.Controls.Add(Password);
            groupBox3.Controls.Add(Username);
            groupBox3.Location = new Point(61, 350);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(510, 133);
            groupBox3.TabIndex = 4;
            groupBox3.TabStop = false;
            groupBox3.Text = "User Credentials";
            // 
            // repass
            // 
            repass.Location = new Point(155, 102);
            repass.Name = "repass";
            repass.Size = new Size(100, 23);
            repass.TabIndex = 5;
            repass.UseSystemPasswordChar = true;
            // 
            // pass
            // 
            pass.Location = new Point(156, 63);
            pass.Name = "pass";
            pass.Size = new Size(100, 23);
            pass.TabIndex = 4;
            pass.UseSystemPasswordChar = true;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(154, 26);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 3;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(32, 110);
            label8.Name = "label8";
            label8.Size = new Size(105, 15);
            label8.TabIndex = 2;
            label8.Text = "Re-enter Password";
            label8.Click += label8_Click;
            // 
            // Password
            // 
            Password.AutoSize = true;
            Password.Location = new Point(32, 71);
            Password.Name = "Password";
            Password.Size = new Size(57, 15);
            Password.TabIndex = 1;
            Password.Text = "Password";
            // 
            // Username
            // 
            Username.AutoSize = true;
            Username.Location = new Point(32, 34);
            Username.Name = "Username";
            Username.Size = new Size(60, 15);
            Username.TabIndex = 0;
            Username.Text = "Username";
            // 
            // passworderror
            // 
            passworderror.AutoSize = true;
            passworderror.ForeColor = Color.Red;
            passworderror.Location = new Point(291, 108);
            passworderror.Name = "passworderror";
            passworderror.Size = new Size(0, 15);
            passworderror.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Info;
            BackgroundImageLayout = ImageLayout.Zoom;
            ClientSize = new Size(800, 567);
            Controls.Add(groupBox3);
            Controls.Add(button1);
            Controls.Add(groupBox2);
            Controls.Add(pictureBox1);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "User Registration Form";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private RadioButton radioButton1;
        private Label label3;
        private TextBox lastname;
        private TextBox firstname;
        private Label label2;
        private Label label1;
        private RadioButton radioButton2;
        private PictureBox pictureBox1;
        private GroupBox groupBox2;
        private Label label4;
        private ComboBox comboBox1;
        private Label label5;
        private ComboBox comboBox2;
        private Button button1;
        private GroupBox groupBox3;
        private TextBox repass;
        private TextBox pass;
        private TextBox textBox3;
        private Label label8;
        private Label Password;
        private Label Username;
        private Label errorlabel;
        private Label passworderror;
    }
}