namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            String fname = firstname.Text;
            String lname = lastname.Text;
            if (fname == "" || lname == "")
            {
                errorlabel.Text = "First name and Last name cannot be empty";

            }
            else if (pass.Text == "" || repass.Text == "")
            {
                passworderror.Text = "Password cannot be empty";
                errorlabel.Text = "";
            }
            else if(pass.Text==repass.Text)
            {
                errorlabel.Text = "";
                passworderror.Text = "";
                MessageBox.Show("Welcome " + fname + " " + lname);
            }
            else
            {
                passworderror.Text = "Password don't match";
            }
           

        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void citySelected(object sender, EventArgs e)
        {
            /*  MessageBox.Show(comboBox1.SelectedItem.ToString());
              String selectedCity = comboBox1.SelectedItem.ToString();*/
            int indexOfSelectedCity = comboBox1.SelectedIndex;
            //MessageBox.Show(indexOfSelectedCity.ToString());
            if (indexOfSelectedCity <= 5)
            {
                //MessageBox.Show("Ontario");
                comboBox2.Text = "Ontario";
            }
            else
            {
                //MessageBox.Show("BC");
                comboBox2.Text = "British Columbia";
            }
        }
    }
}





/*
Vancouver
Surrey
Richmond
Abbotsford
Delta*/