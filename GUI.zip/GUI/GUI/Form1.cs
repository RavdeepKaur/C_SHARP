﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String v1 = textBox1.Text;
            String v2 = textBox2.Text;
            double distance = double.Parse(v1);
            double time = double.Parse(v2);
            double speed = distance / time;
            // MessageBox.Show("Speed of vehicle is "+speed);

            //label3.Text = "Speed of Vehicle is " + speed+ "km/hrs";

            textBox3.Text =  speed + "km/hrs";
        }
    }
}
