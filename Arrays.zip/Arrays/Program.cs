﻿/*Method-1
 * int[] marks = new int[5];
marks[0] = 10;
marks[1] = 11;
marks[2] = 12;
marks[3] = 13;
marks[4] = 14;*/


//int[] marks = {34,56,78,90};
Console.WriteLine("Enter length of array");
int len=Convert.ToInt32(Console.ReadLine());

int[] marks = new int[len];
Console.WriteLine("Enter "+len+" values");
for(int i=0;i<len;i++)
{
    marks[i]=Convert.ToInt32(Console.ReadLine());
}

Console.WriteLine("Array elements are");


for (int i = 0; i < marks.Length; i++)
{
    Console.WriteLine("Value at index "+i+" is "+marks[i]);
}
Console.WriteLine("Array elements in reverse order are");
for (int i = marks.Length-1; i >=0; i--)
{
    Console.WriteLine("Value at index " + i + " is " + marks[i]);
}
Console.WriteLine("Enter the value that you want to search");
int searchValue=Convert.ToInt32(Console.ReadLine());
bool flag = false;
for(int i=0;i<marks.Length;i++)
{
    if (marks[i]==searchValue)
    {
        Console.WriteLine(searchValue + " is present at index " + i);
        flag = true;
        break;
    }
    else
    {   
        flag = false;
       
    }
    
}
if(flag==false)
{
    Console.WriteLine("It is not present in array");
}