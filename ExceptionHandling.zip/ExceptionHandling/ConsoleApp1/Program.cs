﻿try
{
    int x = 89;
    int y = 10;
    double c = x / y;
    Console.WriteLine("Result of Division is "+c);
    Console.WriteLine("Enter required length for array");
    int len = Convert.ToInt32(Console.ReadLine());
    double[] myarray = new double[len];
    Console.WriteLine("Enter " + len + " array elements ");
    for (int i = 0; i < len; i++)
    {
        myarray[i] = Convert.ToDouble(Console.ReadLine());
    }
    Console.WriteLine("Array Elements are");
    for (int i = 0; i <= len; i++)
    {
        Console.WriteLine(myarray[i]);
    }
}
catch(DivideByZeroException e)
{
    Console.WriteLine("Denominator can't be zero");
}
catch (IndexOutOfRangeException e)
{
    Console.Write("Accessing array element which is not present.");
}
catch(Exception e)
{
    Console.WriteLine(e.Message);
}
finally {
    Console.WriteLine("Thank you"); 
}

