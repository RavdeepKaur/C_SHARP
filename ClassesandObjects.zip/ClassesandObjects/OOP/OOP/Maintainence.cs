﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    internal class Maintainence:Vehicle
    {
        public String nameOfTechnician;
        double brakeFluidCost;
        double wheelAlignmentCost;
        double tireReplacementCost;
        double wrapCost;

        public Maintainence(string nameOfTechnician, double brakeFluidCost, double wheelAlignmentCost, double tireReplacementCost, double wrapCost, String name, String color,int model, double price) : base(name,color,model,price)
        {
            this.nameOfTechnician = nameOfTechnician;
            this.brakeFluidCost = brakeFluidCost;
            this.wheelAlignmentCost = wheelAlignmentCost;
            this.tireReplacementCost = tireReplacementCost;
            this.wrapCost = wrapCost;
        }
        public double calculateMaintainenceCharges()
        {
            double amount = this.brakeFluidCost + this.wheelAlignmentCost + this.tireReplacementCost + this.wrapCost;
            return amount;
        }
    }
}
