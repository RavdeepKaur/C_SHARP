﻿// See https://aka.ms/new-console-template for more information
using OOP;
/*
Console.WriteLine("Demonstration of classes");
Vehicle Tesla = new Vehicle("Tesla-X","White",2023,140000.78); //creating object for Vehicle class
//Tesla.display(); 
Console.WriteLine("Trying accessor and mutator functions");
Tesla.Name = "Tesla-Y"; //calling mutator function
Console.WriteLine("Updated Name according to accessor method is "+Tesla.Name);  //calling accessor function

Console.WriteLine(Tesla.Name + " can go for " + Tesla.mileRange() + " miles when fully charged."); //calling mileRange() and accessor function
Console.WriteLine(Tesla.toString());*/

Console.WriteLine("Demonstration of inheritance");
Maintainence log1 = new Maintainence("John",200,275,3000,3500,"Tesla-Y","White",2023,1350000.00);
Console.WriteLine("Calling function from Parent Class");
log1.display();
Console.WriteLine("Calling functions from Child Class");
Console.WriteLine("Maintainance charged by technician " + log1.nameOfTechnician + " is $" + log1.calculateMaintainenceCharges());