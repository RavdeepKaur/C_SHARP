﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    internal class Vehicle
    {
        public string name;
        public string color;
        public int model;
        public double price;
        public Vehicle(string n,string c,int m,double p)
        {
            name= n;
            color= c;
            model= m;
            price= p;
        }
        public string Name
        {
            get=>name;
            set=>name= value;
        }
        public int mileRange()
        {
            int miles = 0;
            if (name.ToLower()=="tesla-x")
            {
                miles = 332;
            }
            else if(name.ToLower()=="tesla-y")
            {
                miles = 303;
            }
            else
            {
                Console.WriteLine("This is invalid model name");
            }
            return miles;
            
        }
      public void display()
        {
            Console.WriteLine("Details of Vehicle are ");
            Console.WriteLine("Name "+name);
            Console.WriteLine("Color " + color);
            Console.WriteLine("Model "+model);
            Console.WriteLine("Price " + price);
        }
        public String toString()
        {
            return "Details of Vehicle are: Name-" + name + " Color-" + color + " Model-" + model+ " Price-" + price;
        }
        ~Vehicle()
        {
            Console.WriteLine("Objects are destroyed");
        }

    }
}
