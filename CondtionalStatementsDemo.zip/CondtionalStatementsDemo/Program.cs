﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CondtionalStatementsDemo
{
   internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Comparing two numbers ");
            Console.WriteLine("Enter first number ");
            int n1=int.Parse(Console.ReadLine());
            Console.WriteLine("Enter second number ");
            int n2=int.Parse(Console.ReadLine());
            if(n1>n2)
            {
                Console.WriteLine(n1+" is largest");
            }
            else
            {
                Console.WriteLine(n2+" is Largest");
            }
            
        }
    }
}
        
        
