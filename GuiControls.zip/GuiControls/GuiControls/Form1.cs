﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuiControls
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if(comboBox1.SelectedIndex==0)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("PROG-1781");
                comboBox2.Items.Add("MATH-1910");
            }
            if(comboBox1.SelectedIndex==1)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("PROG-1815");
                comboBox2.Items.Add("MATH-1920");
            }
        }
    }
}
